package buildet_DP;

public class Main {
	public static void main(String[] args) {
		//Computer  c= new Computer("CPU",2,32,"game","windows");
		Computer c = new Computer.Builder().setOs("Windows").setRam(10).getComputer();
		System.out.println(c);
	}

}
