package buildet_DP;

public class Computer {
	
	private String cpu;
	private int ram;
	private int storage;
	private String graphics_card;
	private String os;
	
	
	@Override
	public String toString() {
		return "Computer [cpu=" + cpu + ", ram=" + ram + ", storage=" + storage + ", graphics_card=" + graphics_card
				+ ", os=" + os + "]";
	}


	
	
	public Computer(String cpu, int ram, int storage, String graphics_card, String os) {
		super();
		this.cpu = cpu;
		this.ram = ram;
		this.storage = storage;
		this.graphics_card = graphics_card;
		this.os = os;
	}
	
//	public Computer(Builder builder) {
//		// TODO Auto-generated constructor stub
//	}

	public static class Builder{
		
		private String cpu;
		private int ram;
		private int storage;
		private String graphics_card;
		private String os;
		
		
		public Builder setCpu(String cpu) {
			this.cpu = cpu;
			return this;
		}

		public Builder setRam(int ram) {
			this.ram = ram;
			return this;
		}

		public Builder setStorage(int storage) {
			this.storage = storage;
			return this;
		}

		public Builder setGraphics_card(String graphics_card) {
			this.graphics_card = graphics_card;
			return this;
		}

		public Builder setOs(String os) {
			this.os = os;
			return this;
		}
		
		
		public Computer getComputer(){
//			Computer c= new Computer(this);
//			return c;
			return new Computer(cpu,ram,storage,graphics_card,os);
		}
		
	}
	
	
	
}
//Build a Computer object with various configurations, that can lead to a complex constructor or a large number of constructors to handle all possible configurations. Instead, use the Builder Design Pattern to simplify the creation process.
//1. Computer Class: Contains private fields for all configurable options and a private constructor that takes a Builder instance.
//(attributes: CPU,RAM,Storage,Graphics Card and Operating System)
//2. Builder Class: Nested static class inside Computer. It has methods to set each optional parameter and a build method to create a Computer object.
//3. Main Class: Demonstrates creating Computer objects using the Builder class.