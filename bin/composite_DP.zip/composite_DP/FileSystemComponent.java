package composite_DP;

public interface FileSystemComponent {
	void display();
}
