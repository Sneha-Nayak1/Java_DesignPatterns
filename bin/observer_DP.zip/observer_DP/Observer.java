package observer_DP;

public interface Observer {
	void update(String temp, String humidity, String pressure);
}
