package proxy_DP;

public class RealClass implements File{
	@Override
	public void download(String fileName) {
		System.out.println("File name is: "+ fileName);
		
	}

}
