package proxy_DP;

public interface File {
	void download(String filename);

}
