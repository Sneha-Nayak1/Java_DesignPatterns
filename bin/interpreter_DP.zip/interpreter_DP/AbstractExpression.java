package interpreter_DP;

public interface AbstractExpression {
	public int interpret(Context context);

}
