package Adapter_DP;

public interface MP4IF {
	public void play();

}
