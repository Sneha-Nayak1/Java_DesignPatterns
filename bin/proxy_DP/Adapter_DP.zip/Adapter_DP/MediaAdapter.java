package Adapter_DP;

public class MediaAdapter implements MediaPlayer{

	VLC v=new VLC("vlc");
	MP4 m=new MP4("mp4");
	
	@Override
	public void playMedia() {
		// TODO Auto-generated method stub
		v.play();
		m.play();
		
	}

}
