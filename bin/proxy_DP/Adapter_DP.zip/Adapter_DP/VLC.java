package Adapter_DP;

public class VLC implements VLCIF{
	
	String s;
	public VLC(String s) {
		this.s=s;
	}
	@Override
	public void play() {
		// TODO Auto-generated method stub
		System.out.println(s);
	}

	
}
