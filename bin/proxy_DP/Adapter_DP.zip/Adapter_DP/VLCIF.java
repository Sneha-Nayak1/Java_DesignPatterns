package Adapter_DP;

public interface VLCIF {
	public void play();

}
