package Adapter_DP;

public interface MediaPlayer {
	public void playMedia();

}
