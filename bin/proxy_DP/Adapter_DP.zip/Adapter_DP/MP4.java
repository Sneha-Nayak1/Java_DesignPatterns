package Adapter_DP;

public class MP4 implements MP4IF{
	String s;
	
	public MP4(String s) {
		this.s=s;
	}
	@Override
	public void play() {
		// TODO Auto-generated method stub
		
		System.out.println(s);
		
	}

	

}
