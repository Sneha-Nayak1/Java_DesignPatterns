package factory_DP;

public interface Vehicle {
	
	public void getType();
	public void getNumberOfWheels();
	public void getCapacity();

}
