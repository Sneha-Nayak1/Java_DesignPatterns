package mediator_DP;

public interface Colleague {
	void send(String s);
	void receive(String s);
}
