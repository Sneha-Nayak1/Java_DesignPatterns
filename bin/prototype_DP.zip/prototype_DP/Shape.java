package prototype_DP;

public interface Shape extends Cloneable{
	Shape clone();
	void displayInfo();
}
