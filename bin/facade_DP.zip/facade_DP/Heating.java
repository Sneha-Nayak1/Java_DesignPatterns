package facade_DP;

public class Heating {
	
	public void isActive() {
		System.out.println("Heating is active");
	}
	
	public void isInActive() {
		System.out.println("Heating is inactive");
	}

}
