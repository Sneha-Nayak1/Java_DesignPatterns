package facade_DP;

public class Security {
	
	public void isSecure() {
		System.out.println("Full Security");
	}
	
	public void noSecure() {
		System.out.println("No Security");
	}

}
