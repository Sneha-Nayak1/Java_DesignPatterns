package facade_DP;

public class Lighting {
	
	public void on() {
		System.out.println("Light is ON");
	}
	public void of() {
		System.out.println("Light is OFF");
	}

}
