package abstractFactory_DP;

public interface Button {
  public void Display_Button();
}
