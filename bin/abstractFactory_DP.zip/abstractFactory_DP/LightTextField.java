package abstractFactory_DP;

public class LightTextField implements TextField{

	@Override
	public void Display_Text() {
		// TODO Auto-generated method stub
		System.out.println("LightTextField");
	}

}
