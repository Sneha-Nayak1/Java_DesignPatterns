package abstractFactory_DP;

public class DarkButton implements Button{

	@Override
	public void Display_Button() {
		// TODO Auto-generated method stub
		System.out.println("Dark Button");
	}

}
