package abstractFactory_DP;

public interface TextField {
	public void Display_Text();
}
