package abstractFactory_DP;

public class LightButton implements Button{

	@Override
	public void Display_Button() {
		// TODO Auto-generated method stub
		System.out.println("LightButton");
		
	}

}
