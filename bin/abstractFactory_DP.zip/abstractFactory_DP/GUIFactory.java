package abstractFactory_DP;

public interface GUIFactory {
	Button button();
	TextField text();
}
