package abstractFactory_DP;

public class DarkTextField implements TextField{

	@Override
	public void Display_Text() {
		// TODO Auto-generated method stub
		System.out.println("DarkTextField");
	}

}
