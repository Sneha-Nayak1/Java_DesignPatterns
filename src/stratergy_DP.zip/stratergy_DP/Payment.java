package stratergy_DP;

public interface Payment {
	public void paymentMethod();
}
