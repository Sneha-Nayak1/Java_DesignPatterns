package stratergy_DP;

public class CreditCard implements Payment{

	@Override
	public void paymentMethod() {
		System.out.println("Payment done through Credit Card!!");
	}

}
