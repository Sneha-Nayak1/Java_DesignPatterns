package stratergy_DP;

public class Bitcoin implements Payment{

	@Override
	public void paymentMethod() {
		System.out.println("Payment done through Biticon!!");
	}

}
