package visitor_DP;

public interface Visitor {
	void visit(File2 f);
	void visit(Directory2 d);
}
