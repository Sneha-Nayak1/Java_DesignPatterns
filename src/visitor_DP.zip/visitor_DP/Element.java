package visitor_DP;

public interface Element {
	void accept(Visitor v);
}
