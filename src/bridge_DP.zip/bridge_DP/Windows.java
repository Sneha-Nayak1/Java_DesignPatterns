package bridge_DP;

public class Windows implements Device{

	@Override
	public void playAudio() {
		// TODO Auto-generated method stub
		System.out.println("Playing Audio in Windows");
		
	}

	@Override
	public void playVideo() {
		// TODO Auto-generated method stub
		System.out.println("Playing Video in Windows");
		
	}

}
