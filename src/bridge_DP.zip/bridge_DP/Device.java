package bridge_DP;

public interface Device {
	public void playAudio();
	public void playVideo();

}
