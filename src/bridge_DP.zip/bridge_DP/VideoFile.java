package bridge_DP;

public class VideoFile extends MediaFile{

	public VideoFile(Device d1) {
		super(d1);
		// TODO Auto-generated constructor stub
	}

	@Override
	void media() {
		// TODO Auto-generated method stub
	
		d1.playVideo();
		//d2.playVideo();
	}

}
