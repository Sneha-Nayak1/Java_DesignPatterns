package bridge_DP;

public class Mac implements Device{

	@Override
	public void playAudio() {
		// TODO Auto-generated method stub
		System.out.println("Playing Audio in Mac");
		
	}

	@Override
	public void playVideo() {
		// TODO Auto-generated method stub
		System.out.println("Playing Video in Mac");
	}

}
