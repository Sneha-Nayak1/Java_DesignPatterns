package decorator_DP;

public interface Coffee {
	double getCost();
	String getDescription();

}
