package decorator_DP;

public class SimpleCoffee implements Coffee{
	@Override
	public double getCost() {
		return 180.0;
		
	}

	@Override
	public String getDescription() {
		// TODO Auto-generated method stub
		return "Simple Coffee";
		
	}

}
