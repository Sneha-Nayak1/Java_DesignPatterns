package template_DP;

public class JSONFile extends DataProcessor{
	@Override
	void reading() {
		System.out.println("Reading JSON File");
		
	}

	@Override
	void parsing() {
		System.out.println("Parsing JSON File");
	}

	@Override
	void saving() {
		System.out.println("Saving JSON File");
	}
}
