package template_DP;

public class CSVFile extends DataProcessor{

	@Override
	void reading() {
		System.out.println("Reading CSV File");
		
	}

	@Override
	void parsing() {
		System.out.println("Parsing CSV File");
	}

	@Override
	void saving() {
		System.out.println("Saving CSV File");
	}

}
