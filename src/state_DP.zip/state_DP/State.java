package state_DP;

public interface State {
	public void change(Context c);

}
