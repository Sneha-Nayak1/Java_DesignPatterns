package flyweight_DP;

public interface CharacterInt {
	void render(String font, String color);

	

}
